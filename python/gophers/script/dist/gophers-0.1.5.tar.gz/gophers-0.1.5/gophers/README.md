# Gophers

## The Go dataframe library - available as python & javascript (wasm) packages.

## Install the python package
### python -m pip install gophers
