
from gophers import gophers

def main():
    gophers.main()

if __name__ == "__main__":
    main()
